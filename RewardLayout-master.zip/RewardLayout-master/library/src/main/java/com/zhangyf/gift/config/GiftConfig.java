package com.zhangyf.gift.config;

/**
 * 这里只是给个demo以后部分参数如礼物名称礼物id从服务器对象返回
 * Created by zhangyf on 2017/3/30.
 */

public class GiftConfig {

//    private int giftCount = 4;
//    private int[] giftIds = new int[] {1,2,3,4};
//    private int[] giftRes = new int[] {R.mipmap.tg,R.mipmap.good,R.mipmap.banana,R.mipmap.yw};
//    private String[] giftNames = new String[] {"糖果","666","小香蕉","鱼丸"};
//    private long[] stayTime = new long[] {2000,2500,2700,3000};

//    private GiftConfig() {}
//
//    public static GiftConfig getInstance() {
//        return GiftHolder.holder;
//    }
//
//    private static class GiftHolder {
//        private static GiftConfig holder = new GiftConfig();
//    }
//
//    public GiftConfig setGiftCount(int count) {
//        this.giftCount = count;
//        return this;
//    }
//
//    public int getGiftCount() {
//        return giftCount;
//    }

//    public GiftConfig setGiftIds(int[] ids) {
//        this.giftIds = ids;
//        return this;
//    }
//
//    public int[] getGiftIds() {
//        return giftIds;
//    }

//    public GiftConfig setGiftRes(int[] res) {
//        this.giftRes = res;
//        return this;
//    }
//
//    public int[] getGiftRes() {
//        return giftRes;
//    }
//
////    public GiftConfig setGiftNames(String[] names) {
////        this.giftNames = names;
////        return this;
////    }
////
////    public String[] getGiftNames() {
////        return giftNames;
////    }
//
//    public GiftConfig setStayTimes(long[] times) {
//        this.stayTime = times;
//        return this;
//    }
//
//    public long[] getStayTime() {
//        return stayTime;
//    }

}
