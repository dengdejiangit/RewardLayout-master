package com.zhangyf.reward;

import android.app.Application;



/**
 * Created by zhangyf on 2017/5/26.
 */

public class MApplication extends Application{

    @Override
    public void onCreate() {
        super.onCreate();
    }
}
